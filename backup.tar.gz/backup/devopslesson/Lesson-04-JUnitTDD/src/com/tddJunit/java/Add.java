package com.tddJunit.java;


public interface Add {

  long add(long... operands);

}
